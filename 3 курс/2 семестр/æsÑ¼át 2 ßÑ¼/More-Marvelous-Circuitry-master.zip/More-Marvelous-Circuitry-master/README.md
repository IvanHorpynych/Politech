# More-Marvelous-Circuitry
Labworks for 'Computer Circuitry II' discipline

Instruments:
 - Computing system work modeling program implemented on sectioned kit KM1804 (KPI, Department of Computer Engineering)

Contents:
 - LW1: Linear microassembler program
 - LW2: Program with branching
 - LW3: Complex mathematical operations
 - LW4: Emulation of Assembler's instructions
