#include <QtGui/QApplication>
#include "steganography.h"
#include <QFile>
#include <iostream>
using namespace std;
int main(int argc, char *argv[])
{
    QApplication app(argc, argv);
    Steganography w;
    w.show();
    return app.exec();
}
