﻿using System.Windows.Forms;

namespace MySQLUserManager
{
    public partial class LimitsForm : Form
    {
        public LimitsForm(string to)
        {
            InitializeComponent();

            this.to.Text = to;
        }

        private void ok_Click(object sender, System.EventArgs e)
        {
            int d;
            if (!int.TryParse(qph.Text, out d) ||
                !int.TryParse(uph.Text, out d) ||
                !int.TryParse(cph.Text, out d) ||
                !int.TryParse(uc.Text, out d))
            {
                MessageBox.Show(this, "All fields must be valid integers.", "Error", MessageBoxButtons.OK,
                                MessageBoxIcon.Exclamation);

                DialogResult = DialogResult.None; ;
            }
        }

        public string QPH { get { return qph.Text; } }
        public string UPH { get { return uph.Text; } }
        public string CPH { get { return cph.Text; } }
        public string UC { get { return uc.Text; } }
    }
}
