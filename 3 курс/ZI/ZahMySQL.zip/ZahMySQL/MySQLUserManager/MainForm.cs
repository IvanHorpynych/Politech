﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

using MySql.Data.MySqlClient;

namespace MySQLUserManager
{
    public partial class MainForm : Form
    {
        private MySqlConnection _connection;
        private Dictionary<string, List<string>> _databases;

        public MainForm()
        {
            InitializeComponent();
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show(this, "MySQL User Manager by aquirel@kpi.cc & vadya.poiuj@gmail.com", "About", MessageBoxButtons.OK,
                            MessageBoxIcon.Information);
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (null != _connection)
                _connection.Close();

            Application.Exit();
        }

        private void connect_Click(object sender, EventArgs e)
        {
            try
            {
                if (null != _connection)
                    _connection.Close();

                _connection =
                    new MySqlConnection(string.Format("server={0};port={1};user={2};password={3};database=mysql",
                                                      host.Text, port.Text, login.Text, password.Text));
                _connection.Open();
            }
            catch
            {
                if (null != _connection)
                    _connection.Close();

                throw;
            }

            toolStripStatusLabel.Text = "Connected to server";

            // List users.
            var cmd = new MySqlCommand("SELECT Host, User FROM mysql.user", _connection);
            MySqlDataReader reader = null;
            try
            {
                reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    user.Items.Add(string.Format("'{0}'@'{1}'", reader.GetString("User"), reader.GetString("Host")));
                }
            }
            finally
            {
                if (null != reader)
                    reader.Close();
            }

            // Get databases.
            _databases = new Dictionary<string, List<string>>();
            cmd = new MySqlCommand("SHOW DATABASES", _connection);
            reader = null;

            try
            {
                reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    _databases.Add(reader.GetString(0), new List<string>());
                }
            }
            finally
            {
                if (null != reader)
                    reader.Close();
            }

            // Get database tables.
            foreach (var kvp in _databases)
            {
                cmd = new MySqlCommand(string.Format("SHOW TABLES FROM {0}", MySqlHelper.EscapeString(kvp.Key)), _connection);
                reader = null;

                try
                {
                    reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        kvp.Value.Add(reader.GetString(0));
                    }
                }
                finally
                {
                    if (null != reader)
                        reader.Close();
                }
            }

            // Get database events.
            cmd = new MySqlCommand("SELECT EVENT_SCHEMA, EVENT_NAME FROM `information_schema`.events", _connection);
            reader = null;

            try
            {
                reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    _databases[reader.GetString(0)].Add(reader.GetString(1));
                }
            }
            finally
            {
                if (null != reader)
                    reader.Close();
            }

            // Get database procedures and functions.
            cmd = new MySqlCommand("SELECT ROUTINE_SCHEMA, ROUTINE_NAME FROM `information_schema`.routines", _connection);
            reader = null;

            try
            {
                reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    _databases[reader.GetString(0)].Add(reader.GetString(1));
                }
            }
            finally
            {
                if (null != reader)
                    reader.Close();
            }

            // Get database triggers.
            cmd = new MySqlCommand("SELECT TRIGGER_SCHEMA, TRIGGER_NAME FROM `information_schema`.triggers", _connection);
            reader = null;

            try
            {
                reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    _databases[reader.GetString(0)].Add(reader.GetString(1));
                }
            }
            finally
            {
                if (null != reader)
                    reader.Close();
            }
        }

        private void remove_Click(object sender, EventArgs e)
        {
            if (null == _connection)
                return;

            if (null == user.SelectedItem)
                return;

            var cmd = new MySqlCommand(string.Format("DROP USER {0}", user.SelectedItem as string), _connection);
            cmd.ExecuteNonQuery();
            user.Items.Remove(user.SelectedItem);
            MessageBox.Show(this, "User dropped.", "Info", MessageBoxButtons.OK,
                            MessageBoxIcon.Information);
        }

        private void add_Click(object sender, EventArgs e)
        {
            if (null == _connection)
                return;

            var accountForm = new AccountForm();
            if (DialogResult.OK != accountForm.ShowDialog(this))
                return;

            var createUserCommand = new StringBuilder();
            createUserCommand.Append(string.Format("CREATE USER '{0}'", MySqlHelper.EscapeString(accountForm.Login)));

            if (!string.IsNullOrEmpty(accountForm.Host))
            {
                createUserCommand.Append(string.Format("@'{0}'", MySqlHelper.EscapeString(accountForm.Host)));
            }

            if (!string.IsNullOrEmpty(accountForm.Password))
            {
                createUserCommand.Append(string.Format(" IDENTIFIED BY '{0}'", MySqlHelper.EscapeString(accountForm.Password)));
            }

            if (DialogResult.Yes != MessageBox.Show(this, createUserCommand.ToString(), "Perform action?", MessageBoxButtons.YesNo,
                            MessageBoxIcon.Question))
                return;

            var cmd = new MySqlCommand(createUserCommand.ToString(), _connection);
            cmd.ExecuteNonQuery();
            user.Items.Add(string.Format("'{0}'@'{1}'", MySqlHelper.EscapeString(accountForm.Login), MySqlHelper.EscapeString(accountForm.Host)));
            MessageBox.Show(this, "User added.", "Info", MessageBoxButtons.OK,
                            MessageBoxIcon.Information);

            user.SelectedIndex = user.Items.Count - 1;
        }

        private void edit_Click(object sender, EventArgs e)
        {
            if (null == _connection)
                return;

            if (null == user.SelectedItem)
                return;

            var selectedUser = user.SelectedItem as string;
            var username = selectedUser.Substring(1, selectedUser.IndexOf('@') - 2);
            var host = selectedUser.Substring(selectedUser.IndexOf('@') + 2);
            host = host.Substring(0, host.Length - 1);

            var accountForm = new AccountForm { Login = username, Host = host };
            if (DialogResult.OK != accountForm.ShowDialog(this))
                return;

            var updatePasswordCommand = new StringBuilder();
            updatePasswordCommand.Append(string.Format("SET PASSWORD FOR {0} = PASSWORD('{1}')",
                                                        selectedUser,
                                                        MySqlHelper.EscapeString(accountForm.Password)));

            if (DialogResult.Yes == MessageBox.Show(this, updatePasswordCommand.ToString(), "Perform action?", MessageBoxButtons.YesNo,
                            MessageBoxIcon.Question))
            {
                var passwordCmd = new MySqlCommand(updatePasswordCommand.ToString(), _connection);
                passwordCmd.ExecuteNonQuery();

                MessageBox.Show(this, "Password changed.", "Info", MessageBoxButtons.OK,
                                MessageBoxIcon.Information);

                if (MySqlHelper.EscapeString(accountForm.Login) == username &&
                    MySqlHelper.EscapeString(accountForm.Host) == host)
                    return;
            }

            var updateUserCommand = new StringBuilder();
            updateUserCommand.Append(string.Format("RENAME USER {0} TO '{1}'", selectedUser,
                                                   MySqlHelper.EscapeString(accountForm.Login)));
            if (!string.IsNullOrEmpty(accountForm.Host))
            {
                updateUserCommand.Append(string.Format("@'{0}'", MySqlHelper.EscapeString(accountForm.Host)));
            }

            if (DialogResult.Yes != MessageBox.Show(this, updateUserCommand.ToString(), "Perform action?", MessageBoxButtons.YesNo,
                            MessageBoxIcon.Question))
                return;

            var cmd = new MySqlCommand(updateUserCommand.ToString(), _connection);
            cmd.ExecuteNonQuery();

            user.Items[user.SelectedIndex] = string.Format("'{0}'@'{1}'",
                                                           MySqlHelper.EscapeString(accountForm.Login),
                                                           MySqlHelper.EscapeString(accountForm.Host));

            MessageBox.Show(this, "User edited.", "Info", MessageBoxButtons.OK,
                            MessageBoxIcon.Information);
        }

        private void user_SelectedIndexChanged(object sender, EventArgs e)
        {
            UpdatePrivilegesInfo();
        }

        private void UpdatePrivilegesInfo()
        {
            priviliges.Text = "";

            if (null == _connection)
                return;

            if (null == user.SelectedItem)
                return;

            var priviligesRequestCommand = new StringBuilder();
            priviligesRequestCommand.Append(string.Format("SHOW GRANTS FOR {0}", user.SelectedItem));
            var cmd = new MySqlCommand(priviligesRequestCommand.ToString(), _connection);
            MySqlDataReader reader = null;

            try
            {
                reader = cmd.ExecuteReader();
                priviliges.Text += reader.GetName(0) + Environment.NewLine;

                while (reader.Read())
                {
                    priviliges.Text += reader.GetString(0) + Environment.NewLine;
                }
            }
            finally
            {
                if (null != reader)
                    reader.Close();
            }
        }

        private void grant_Click(object sender, EventArgs e)
        {
            if (null == _connection)
                return;

            if (null == user.SelectedItem)
                return;

            var grantForm = new PrivilegeForm(user.SelectedItem as string, _databases);
            if (DialogResult.OK != grantForm.ShowDialog(this))
                return;

            var grantCommand = new StringBuilder();
            grantCommand.Append(string.Format("GRANT {0} {1} ON {2} {3} TO {4} {5}",
                                              grantForm.PrivilegeType,
                                              grantForm.Columns,
                                              grantForm.ObjectType ?? "",
                                              grantForm.PrivilegeLevel,
                                              user.SelectedItem as string,
                                              grantForm.WithGrant ? "WITH GRANT OPTION" : ""));

            if (DialogResult.Yes != MessageBox.Show(this, grantCommand.ToString(), "Perform action?", MessageBoxButtons.YesNo,
                            MessageBoxIcon.Question))
                return;

            var cmd = new MySqlCommand(grantCommand.ToString(), _connection);
            cmd.ExecuteNonQuery();

            UpdatePrivilegesInfo();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (null == _connection)
                return;

            if (null == user.SelectedItem)
                return;

            var revokeForm = new PrivilegeForm(user.SelectedItem as string, _databases);
            if (DialogResult.OK != revokeForm.ShowDialog(this))
                return;

            var revokeCommand = new StringBuilder();
            revokeCommand.Append(string.Format("REVOKE {0}{1} {2} {3} {4} {5} FROM {6}",
                                              revokeForm.PrivilegeType,
                                              (revokeForm.WithGrant && string.IsNullOrEmpty(revokeForm.ObjectType) && string.IsNullOrEmpty(revokeForm.PrivilegeLevel)) ? ", GRANT OPTION" : "",
                                              revokeForm.Columns,
                                              (!string.IsNullOrEmpty(revokeForm.ObjectType) || !string.IsNullOrEmpty(revokeForm.PrivilegeLevel)) ? "ON" : "",
                                              revokeForm.ObjectType ?? "",
                                              revokeForm.PrivilegeLevel,
                                              user.SelectedItem as string));

            if (DialogResult.Yes != MessageBox.Show(this, revokeCommand.ToString(), "Perform action?", MessageBoxButtons.YesNo,
                            MessageBoxIcon.Question))
                return;

            var cmd = new MySqlCommand(revokeCommand.ToString(), _connection);
            cmd.ExecuteNonQuery();

            UpdatePrivilegesInfo();
        }

        private void limits_Click(object sender, EventArgs e)
        {
            if (null == _connection)
                return;

            if (null == user.SelectedItem)
                return;

            var limitsForm = new LimitsForm(user.SelectedItem as string);
            if (DialogResult.OK != limitsForm.ShowDialog(this))
                return;

            var limitCommand = new StringBuilder();
            limitCommand.Append(string.Format("GRANT USAGE ON *.* TO {0} WITH MAX_QUERIES_PER_HOUR {1} MAX_UPDATES_PER_HOUR {2} MAX_CONNECTIONS_PER_HOUR {3} MAX_USER_CONNECTIONS {4}",
                                              user.SelectedItem as string,
                                              limitsForm.QPH,
                                              limitsForm.UPH,
                                              limitsForm.CPH,
                                              limitsForm.UC));

            if (DialogResult.Yes != MessageBox.Show(this, limitCommand.ToString(), "Perform action?", MessageBoxButtons.YesNo,
                            MessageBoxIcon.Question))
                return;

            var cmd = new MySqlCommand(limitCommand.ToString(), _connection);
            cmd.ExecuteNonQuery();

            UpdatePrivilegesInfo();
        }

        private void MainForm_KeyDown(object sender, KeyEventArgs e)
        {
            if (Keys.Escape == e.KeyCode)
                Application.Exit();
        }

        private void flush_Click(object sender, EventArgs e)
        {
            if (null == _connection)
                return;

            const string flushCommand = "FLUSH PRIVILEGES";
            if (DialogResult.Yes != MessageBox.Show(this, flushCommand, "Perform action?", MessageBoxButtons.YesNo,
                            MessageBoxIcon.Question))
                return;

            var cmd = new MySqlCommand(flushCommand, _connection);
            cmd.ExecuteNonQuery();

            UpdatePrivilegesInfo();
        }
    }
}
