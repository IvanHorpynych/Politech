﻿namespace MySQLUserManager
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.statusStrip = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.mainMenu = new System.Windows.Forms.MenuStrip();
            this.connectionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.port = new System.Windows.Forms.TextBox();
            this.host = new System.Windows.Forms.TextBox();
            this.password = new System.Windows.Forms.TextBox();
            this.login = new System.Windows.Forms.TextBox();
            this.connect = new System.Windows.Forms.Button();
            this.user = new System.Windows.Forms.ComboBox();
            this.add = new System.Windows.Forms.Button();
            this.edit = new System.Windows.Forms.Button();
            this.remove = new System.Windows.Forms.Button();
            this.priviliges = new System.Windows.Forms.TextBox();
            this.grant = new System.Windows.Forms.Button();
            this.revoke = new System.Windows.Forms.Button();
            this.limits = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.flush = new System.Windows.Forms.Button();
            this.statusStrip.SuspendLayout();
            this.mainMenu.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // statusStrip
            // 
            this.statusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel});
            this.statusStrip.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.Flow;
            this.statusStrip.Location = new System.Drawing.Point(0, 256);
            this.statusStrip.Name = "statusStrip";
            this.statusStrip.ShowItemToolTips = true;
            this.statusStrip.Size = new System.Drawing.Size(574, 19);
            this.statusStrip.SizingGrip = false;
            this.statusStrip.TabIndex = 12;
            this.statusStrip.Text = "statusStrip";
            // 
            // toolStripStatusLabel
            // 
            this.toolStripStatusLabel.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripStatusLabel.Name = "toolStripStatusLabel";
            this.toolStripStatusLabel.Size = new System.Drawing.Size(168, 14);
            this.toolStripStatusLabel.Text = "Not connected to server";
            // 
            // mainMenu
            // 
            this.mainMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.connectionToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.mainMenu.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.Flow;
            this.mainMenu.Location = new System.Drawing.Point(0, 0);
            this.mainMenu.Name = "mainMenu";
            this.mainMenu.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
            this.mainMenu.ShowItemToolTips = true;
            this.mainMenu.Size = new System.Drawing.Size(574, 22);
            this.mainMenu.TabIndex = 0;
            this.mainMenu.Text = "mainMenu";
            // 
            // connectionToolStripMenuItem
            // 
            this.connectionToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exitToolStripMenuItem});
            this.connectionToolStripMenuItem.Name = "connectionToolStripMenuItem";
            this.connectionToolStripMenuItem.Size = new System.Drawing.Size(47, 18);
            this.connectionToolStripMenuItem.Text = "&File";
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(102, 22);
            this.exitToolStripMenuItem.Text = "E&xit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutToolStripMenuItem});
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(47, 18);
            this.helpToolStripMenuItem.Text = "&Help";
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(130, 22);
            this.aboutToolStripMenuItem.Text = "&About...";
            this.aboutToolStripMenuItem.Click += new System.EventHandler(this.aboutToolStripMenuItem_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.port);
            this.groupBox1.Controls.Add(this.host);
            this.groupBox1.Controls.Add(this.password);
            this.groupBox1.Controls.Add(this.login);
            this.groupBox1.Controls.Add(this.connect);
            this.groupBox1.Location = new System.Drawing.Point(12, 25);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(550, 45);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Server connection";
            // 
            // port
            // 
            this.port.Location = new System.Drawing.Point(324, 19);
            this.port.Name = "port";
            this.port.Size = new System.Drawing.Size(50, 20);
            this.port.TabIndex = 3;
            this.port.Text = "3306";
            // 
            // host
            // 
            this.host.Location = new System.Drawing.Point(218, 19);
            this.host.Name = "host";
            this.host.Size = new System.Drawing.Size(100, 20);
            this.host.TabIndex = 2;
            this.host.Text = "localhost";
            // 
            // password
            // 
            this.password.Location = new System.Drawing.Point(112, 19);
            this.password.Name = "password";
            this.password.PasswordChar = '*';
            this.password.Size = new System.Drawing.Size(100, 20);
            this.password.TabIndex = 1;
            // 
            // login
            // 
            this.login.Location = new System.Drawing.Point(6, 19);
            this.login.Name = "login";
            this.login.Size = new System.Drawing.Size(100, 20);
            this.login.TabIndex = 0;
            this.login.Text = "root";
            // 
            // connect
            // 
            this.connect.Location = new System.Drawing.Point(380, 17);
            this.connect.Name = "connect";
            this.connect.Size = new System.Drawing.Size(164, 23);
            this.connect.TabIndex = 4;
            this.connect.Text = "&Connect";
            this.connect.UseVisualStyleBackColor = true;
            this.connect.Click += new System.EventHandler(this.connect_Click);
            // 
            // user
            // 
            this.user.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.user.FormattingEnabled = true;
            this.user.Location = new System.Drawing.Point(12, 94);
            this.user.Name = "user";
            this.user.Size = new System.Drawing.Size(121, 21);
            this.user.TabIndex = 3;
            this.user.SelectedIndexChanged += new System.EventHandler(this.user_SelectedIndexChanged);
            // 
            // add
            // 
            this.add.Location = new System.Drawing.Point(12, 121);
            this.add.Name = "add";
            this.add.Size = new System.Drawing.Size(121, 23);
            this.add.TabIndex = 4;
            this.add.Text = "&Add";
            this.add.UseVisualStyleBackColor = true;
            this.add.Click += new System.EventHandler(this.add_Click);
            // 
            // edit
            // 
            this.edit.Location = new System.Drawing.Point(12, 150);
            this.edit.Name = "edit";
            this.edit.Size = new System.Drawing.Size(121, 23);
            this.edit.TabIndex = 5;
            this.edit.Text = "&Edit";
            this.edit.UseVisualStyleBackColor = true;
            this.edit.Click += new System.EventHandler(this.edit_Click);
            // 
            // remove
            // 
            this.remove.Location = new System.Drawing.Point(12, 179);
            this.remove.Name = "remove";
            this.remove.Size = new System.Drawing.Size(121, 23);
            this.remove.TabIndex = 6;
            this.remove.Text = "&Remove";
            this.remove.UseVisualStyleBackColor = true;
            this.remove.Click += new System.EventHandler(this.remove_Click);
            // 
            // priviliges
            // 
            this.priviliges.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.priviliges.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.priviliges.Location = new System.Drawing.Point(139, 76);
            this.priviliges.Multiline = true;
            this.priviliges.Name = "priviliges";
            this.priviliges.ReadOnly = true;
            this.priviliges.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.priviliges.Size = new System.Drawing.Size(423, 148);
            this.priviliges.TabIndex = 7;
            // 
            // grant
            // 
            this.grant.Location = new System.Drawing.Point(139, 230);
            this.grant.Name = "grant";
            this.grant.Size = new System.Drawing.Size(101, 23);
            this.grant.TabIndex = 8;
            this.grant.Text = "&Grant";
            this.grant.UseVisualStyleBackColor = true;
            this.grant.Click += new System.EventHandler(this.grant_Click);
            // 
            // revoke
            // 
            this.revoke.Location = new System.Drawing.Point(246, 230);
            this.revoke.Name = "revoke";
            this.revoke.Size = new System.Drawing.Size(101, 23);
            this.revoke.TabIndex = 9;
            this.revoke.Text = "Re&voke";
            this.revoke.UseVisualStyleBackColor = true;
            this.revoke.Click += new System.EventHandler(this.button2_Click);
            // 
            // limits
            // 
            this.limits.Location = new System.Drawing.Point(353, 230);
            this.limits.Name = "limits";
            this.limits.Size = new System.Drawing.Size(101, 23);
            this.limits.TabIndex = 10;
            this.limits.Text = "&Limits";
            this.limits.UseVisualStyleBackColor = true;
            this.limits.Click += new System.EventHandler(this.limits_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 78);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(32, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "User:";
            // 
            // flush
            // 
            this.flush.Location = new System.Drawing.Point(460, 230);
            this.flush.Name = "flush";
            this.flush.Size = new System.Drawing.Size(102, 23);
            this.flush.TabIndex = 11;
            this.flush.Text = "Fl&ush";
            this.flush.UseVisualStyleBackColor = true;
            this.flush.Click += new System.EventHandler(this.flush_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(574, 275);
            this.Controls.Add(this.flush);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.limits);
            this.Controls.Add(this.revoke);
            this.Controls.Add(this.grant);
            this.Controls.Add(this.priviliges);
            this.Controls.Add(this.remove);
            this.Controls.Add(this.edit);
            this.Controls.Add(this.add);
            this.Controls.Add(this.user);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.statusStrip);
            this.Controls.Add(this.mainMenu);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.MainMenuStrip = this.mainMenu;
            this.MaximizeBox = false;
            this.Name = "MainForm";
            this.Text = "MySQL user manager";
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.MainForm_KeyDown);
            this.statusStrip.ResumeLayout(false);
            this.statusStrip.PerformLayout();
            this.mainMenu.ResumeLayout(false);
            this.mainMenu.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.StatusStrip statusStrip;
        private System.Windows.Forms.MenuStrip mainMenu;
        private System.Windows.Forms.ToolStripMenuItem connectionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox host;
        private System.Windows.Forms.TextBox password;
        private System.Windows.Forms.TextBox login;
        private System.Windows.Forms.Button connect;
        private System.Windows.Forms.TextBox port;
        private System.Windows.Forms.ComboBox user;
        private System.Windows.Forms.Button add;
        private System.Windows.Forms.Button edit;
        private System.Windows.Forms.Button remove;
        private System.Windows.Forms.TextBox priviliges;
        private System.Windows.Forms.Button grant;
        private System.Windows.Forms.Button revoke;
        private System.Windows.Forms.Button limits;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button flush;

    }
}

