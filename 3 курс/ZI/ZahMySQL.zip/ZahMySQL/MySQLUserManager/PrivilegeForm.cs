﻿using System.Collections.Generic;
using System.Windows.Forms;

namespace MySQLUserManager
{
    public partial class PrivilegeForm : Form
    {
        public PrivilegeForm(string to, Dictionary<string, List<string>> databases)
        {
            InitializeComponent();

            this.to.Text = to;

            foreach (var database in databases.Keys)
            {
                privilegeLevel.Items.Add(string.Format("{0}.*", database));
            }

            foreach (var kvp in databases)
            {
                foreach (var item in kvp.Value)
                {
                    privilegeLevel.Items.Add(string.Format("{0}.{1}.*", kvp.Key, item));
                }
            }
        }

        public string PrivilegeType { get { return privilegeType.SelectedItem as string; } }
        public string Columns { get { return columns.Text; } }
        public string ObjectType { get { return objectType.SelectedItem as string; } }
        public string PrivilegeLevel { get { return privilegeLevel.SelectedItem as string; } }
        public bool WithGrant { get { return withGrant.Checked; } }

        private void ok_Click(object sender, System.EventArgs e)
        {
            if (null == privilegeType.SelectedItem)
            {
                MessageBox.Show(this, "Select privilege type", "Error", MessageBoxButtons.OK,
                                MessageBoxIcon.Exclamation);

                DialogResult = DialogResult.None;
            }

            if (string.IsNullOrEmpty(privilegeLevel.Text) && !withGrant.Checked)
            {
                MessageBox.Show(this, "Select privilege level", "Error", MessageBoxButtons.OK,
                                MessageBoxIcon.Exclamation);

                DialogResult = DialogResult.None;
            }
        }
    }
}
