﻿namespace MySQLUserManager
{
    partial class PrivilegeForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ok = new System.Windows.Forms.Button();
            this.cancel = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.privilegeType = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.columns = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.objectType = new System.Windows.Forms.ComboBox();
            this.privilegeLevel = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.withGrant = new System.Windows.Forms.CheckBox();
            this.to = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // ok
            // 
            this.ok.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.ok.Location = new System.Drawing.Point(64, 163);
            this.ok.Name = "ok";
            this.ok.Size = new System.Drawing.Size(100, 23);
            this.ok.TabIndex = 9;
            this.ok.Text = "&OK";
            this.ok.UseVisualStyleBackColor = true;
            this.ok.Click += new System.EventHandler(this.ok_Click);
            // 
            // cancel
            // 
            this.cancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.cancel.Location = new System.Drawing.Point(170, 163);
            this.cancel.Name = "cancel";
            this.cancel.Size = new System.Drawing.Size(100, 23);
            this.cancel.TabIndex = 10;
            this.cancel.Text = "&Cancel";
            this.cancel.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(36, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "What:";
            // 
            // privilegeType
            // 
            this.privilegeType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.privilegeType.FormattingEnabled = true;
            this.privilegeType.Items.AddRange(new object[] {
            "ALL PRIVILEGES",
            "ALTER",
            "ALTER ROUTINE",
            "CREATE",
            "CREATE ROUTINE",
            "CREATE TABLESPACE",
            "CREATE TEMPORARY",
            "CREATE USER",
            "CREATE VIEW",
            "DELETE",
            "DROP",
            "EVENT",
            "EXECUTE",
            "FILE",
            "GRANT OPTION",
            "INDEX",
            "INSERT",
            "LOCK TABLES",
            "PROCESS",
            "PROXY",
            "REFERENCES",
            "RELOAD",
            "REPLICATION CLIENT",
            "REPLICATION SLAVE",
            "SELECT",
            "SHOW DATABASES",
            "SHOW VIEW",
            "SHUTDOWN",
            "SUPER",
            "TRIGGER",
            "UPDATE",
            "USAGE"});
            this.privilegeType.Location = new System.Drawing.Point(80, 6);
            this.privilegeType.Name = "privilegeType";
            this.privilegeType.Size = new System.Drawing.Size(121, 21);
            this.privilegeType.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 36);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "[Columns:]";
            // 
            // columns
            // 
            this.columns.Location = new System.Drawing.Point(80, 33);
            this.columns.Name = "columns";
            this.columns.Size = new System.Drawing.Size(121, 20);
            this.columns.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 62);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(24, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "On:";
            // 
            // objectType
            // 
            this.objectType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.objectType.FormattingEnabled = true;
            this.objectType.Items.AddRange(new object[] {
            "",
            "TABLE",
            "FUNCTION",
            "PROCEDURE"});
            this.objectType.Location = new System.Drawing.Point(80, 59);
            this.objectType.Name = "objectType";
            this.objectType.Size = new System.Drawing.Size(121, 21);
            this.objectType.TabIndex = 5;
            // 
            // privilegeLevel
            // 
            this.privilegeLevel.FormattingEnabled = true;
            this.privilegeLevel.Items.AddRange(new object[] {
            "",
            "*",
            "*.*"});
            this.privilegeLevel.Location = new System.Drawing.Point(80, 86);
            this.privilegeLevel.Name = "privilegeLevel";
            this.privilegeLevel.Size = new System.Drawing.Size(242, 21);
            this.privilegeLevel.TabIndex = 6;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 116);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(23, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "To:";
            // 
            // withGrant
            // 
            this.withGrant.AutoSize = true;
            this.withGrant.Location = new System.Drawing.Point(80, 140);
            this.withGrant.Name = "withGrant";
            this.withGrant.Size = new System.Drawing.Size(75, 17);
            this.withGrant.TabIndex = 11;
            this.withGrant.Text = "With grant";
            this.withGrant.UseVisualStyleBackColor = true;
            // 
            // to
            // 
            this.to.AutoSize = true;
            this.to.Location = new System.Drawing.Point(77, 116);
            this.to.Name = "to";
            this.to.Size = new System.Drawing.Size(0, 13);
            this.to.TabIndex = 12;
            // 
            // PrivilegeForm
            // 
            this.AcceptButton = this.ok;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.cancel;
            this.ClientSize = new System.Drawing.Size(334, 195);
            this.Controls.Add(this.to);
            this.Controls.Add(this.withGrant);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.privilegeLevel);
            this.Controls.Add(this.objectType);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.columns);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.privilegeType);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cancel);
            this.Controls.Add(this.ok);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "PrivilegeForm";
            this.Text = "Privilege constructor";
            this.Icon = System.Drawing.SystemIcons.Shield;
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button ok;
        private System.Windows.Forms.Button cancel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox privilegeType;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox columns;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox objectType;
        private System.Windows.Forms.ComboBox privilegeLevel;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.CheckBox withGrant;
        private System.Windows.Forms.Label to;


    }
}

