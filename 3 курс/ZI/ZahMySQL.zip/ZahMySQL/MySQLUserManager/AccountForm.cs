﻿using System.Windows.Forms;

namespace MySQLUserManager
{
    public partial class AccountForm : Form
    {
        public string Login { get { return login.Text; } set { login.Text = value; } }
        public string Password
        {
            get { return password1.Text; }
            set { password1.Text = value; password2.Text = value; }
        }
        public string Host { get { return host.Text; } set { host.Text = value; } }

        public AccountForm()
        {
            InitializeComponent();
        }

        private void ok_Click(object sender, System.EventArgs e)
        {
            if (password1.Text != password2.Text)
            {
                MessageBox.Show(this, "Passwords don't match.", "Error", MessageBoxButtons.OK,
                                MessageBoxIcon.Exclamation);

                DialogResult = DialogResult.None;
            }

            if (string.IsNullOrEmpty(login.Text))
            {
                MessageBox.Show(this, "Bad login.", "Error", MessageBoxButtons.OK,
                                MessageBoxIcon.Exclamation);

                DialogResult = DialogResult.None;
            }
        }
    }
}
