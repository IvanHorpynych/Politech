<html>
<head><title>(c) L.B. IS LAB4 by Stelmakh Georgiy, KV-93, FPM</title></head>
<body>
<?php
	$host = "localhost";
	$user = "root";
	$passwd = "";
	$database = "mysql";
	echo "Your host is: <b>". $host. "</b>, ";
	echo "and your username is: <b>". $user. "</b><br />";
	echo "Selected database is: <b>". $database. "</b><br />";
	$db = mysql_connect($host,$user,$passwd);
	mysql_select_db($database ,$db);
	
	if(isset($_POST['create']))
	{
?>
		<br />
		Please, enter user name:
		<form action="result.php" method="post">		
			<textarea name="user_name" rows=1 cols=20 wrap="hard"></textarea>
			<!--<textarea name="user_host" rows=1 cols=20 wrap="hard"></textarea>
			<textarea name="user_passwd" rows=1 cols=20 wrap="hard"></textarea>-->
			<input type="hidden" name="create_user" id="confirm" value=""><br />
			<input type="submit" name="enter" value="Go!" >
		</form>

		<br />
		<form action="index.php" method='post'><input type="submit" name="" value='Back' /></form>
		(c) L.B. IS LAB4 by Stelmakh Georgiy, KV-93, FPM
<?php
	}
	else
	{
		echo ("<br /><b>Invalid POST!</b><br />");
?>
		<br />
		<form action="index.php" method='post'><input type="submit" name="" value='Back' /></form>
		(c) L.B. IS LAB4 by Stelmakh Georgiy, KV-93, FPM
<?php
	}
	
	mysql_close($db);
?>
</body>
</html>