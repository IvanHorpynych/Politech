<html>
<head><title>(c) L.B. IS LAB4 by Stelmakh Georgiy, KV-93, FPM</title></head>
<body>
<?php
	$host = "localhost";
	$user = "root";
	$passwd = "";
	$database = "mysql";
	echo "Your host is: <b>". $host. "</b>, ";
	echo "and your username is: <b>". $user. "</b><br />";
	echo "Selected database is: <b>". $database. "</b><br />";
	$db = mysql_connect($host,$user,$passwd);
	mysql_select_db($database ,$db);
	
	if(isset($_POST['usertable']))
	{
		$sql = mysql_query("SELECT * FROM user" ,$db);
		echo ("<br /><b>MySQL User Table:</b>");
		echo ("<table border ='1'>");
		echo ("<tr><td>Username</td><td>Host</td><td>Select Privileges</td><td>Insert Privileges</td><td>Update Privileges</td>
				<td>Delete Privileges</td><td>Create Privileges</td><td>Drop Privileges</td></tr>");

		while($row = mysql_fetch_array($sql))
		{
			echo "<tr><td>". $row['User']. "</td><td>". $row['Host']. "</td><td>". $row['Select_priv']. "</td><td>". $row['Insert_priv']. "</td><td>".
					$row['Update_priv']. "</td><td>". $row['Delete_priv']. "</td><td>". $row['Create_priv']. "</td><td>". $row['Drop_priv']. "</td></tr>";
		}
				
		echo "</table>";
?>
		<br />
		<form action="index.php" method='post'><input type="submit" name="" value='Back' /></form>
		(c) L.B. IS LAB4 by Stelmakh Georgiy, KV-93, FPM
<?php
	}
	else
	{
		echo ("<br /><b>Invalid POST!</b><br />");
?>
		<br />
		<form action="index.php" method='post'><input type="submit" name="" value='Back' /></form>
		(c) L.B. IS LAB4 by Stelmakh Georgiy, KV-93, FPM
<?php
	}
	
	mysql_close($db);
?>
</body>
</html>