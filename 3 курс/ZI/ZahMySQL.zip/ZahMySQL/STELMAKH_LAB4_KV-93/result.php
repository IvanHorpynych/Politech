<html>
<head><title>(c) L.B. IS LAB4 by Stelmakh Georgiy, KV-93, FPM</title></head>
<body>
<?php
	$host = "localhost";
	$user = "root";
	$passwd = "";
	$database = "mysql";
	echo "Your host is: <b>". $host. "</b>, ";
	echo "and your username is: <b>". $user. "</b><br />";
	echo "Selected database is: <b>". $database. "</b><br />";
	$db = mysql_connect($host,$user,$passwd);
	mysql_select_db($database ,$db);
	
	if(isset($_POST['query_launch'])) 
	{
		$query=$_POST["query_val"];
		$sql = mysql_query($query ,$db);
		if( strlen($query)==0 )
		{
			$error="<br /><b>Please, enter a valid Query!<b><br />";
			echo ($error);
		}
		else
		{
			echo ("<br /><b>Successful!</b><br />");
			$i = 0;
			while($row = mysql_fetch_array($sql))
			{
				echo $row[$i]. " ";
				$i++;			
			}
			echo ("<br />");
		}
?>
		<br />
		<form action="index.php" method='post'><input type="submit" name="" value='Back' /></form>
		(c) L.B. IS LAB4 by Stelmakh Georgiy, KV-93, FPM
<?php
	}
	else
	{
		if(isset($_POST['create_user'])) 
		{
			$uname=$_POST["user_name"];
			$sql = mysql_query("CREATE USER ". $uname. "@localhost IDENTIFIED BY 'passwd'" ,$db);
			if( strlen($uname)==0 )
			{
				$error="<br /><b>Please, enter a valid Query!<b><br />";
				echo ($error);
			}
			else
			{
				echo ("<br /><b>Successful!<b><br />");
			}
	?>
			<br />
			<form action="index.php" method='post'><input type="submit" name="" value='Back' /></form>
			(c) L.B. IS LAB4 by Stelmakh Georgiy, KV-93, FPM
<?php
		}
	}
	
	mysql_close($db);
?>
</body>
</html>