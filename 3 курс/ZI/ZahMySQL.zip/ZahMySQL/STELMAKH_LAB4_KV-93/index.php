<html>
<head><title>(c) L.B. IS LAB4 by Stelmakh Georgiy, KV-93, FPM</title></head>
<body>
<?php
	$host = "localhost";
	$user = "root";
	$passwd = "";
	$database = "mysql";
	echo "Your host is: <b>". $host. "</b>, ";
	echo "and your username is: <b>". $user. "</b><br />";
	echo "Selected database is: <b>". $database. "</b><br />";
	$db = mysql_connect($host,$user,$passwd);
	mysql_select_db($database ,$db);
	
?>
	<br />
	<form action="users.php" method="post"><input type="submit" name="usertable" value="Show user table" /></form>
	<form action="create.php" method="post"><input type="submit" name="create" value="Create user" /></form>
	<form action="query.php" method="post"><input type="submit" name="query" value="Execute query" /></form>
	(c) L.B. IS LAB4 by Stelmakh Georgiy, KV-93, FPM
	
<?php
	mysql_close($db);
?>
</body>
</html>