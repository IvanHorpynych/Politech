﻿namespace ZI_4
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Conbutton1 = new System.Windows.Forms.Button();
            this.loginlabel = new System.Windows.Forms.Label();
            this.passlabel = new System.Windows.Forms.Label();
            this.LogintextBox = new System.Windows.Forms.TextBox();
            this.PasstextBox = new System.Windows.Forms.TextBox();
            this.Quitbutton = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.NameNewtextBox2 = new System.Windows.Forms.TextBox();
            this.Namelabel = new System.Windows.Forms.Label();
            this.Grantlabel = new System.Windows.Forms.Label();
            this.GrantNewtextBox3 = new System.Windows.Forms.TextBox();
            this.Cratebutton = new System.Windows.Forms.Button();
            this.CreatNewbutton1 = new System.Windows.Forms.Button();
            this.NewDbtextBox4 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.PassNewtextBox4 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.ConsoletextBox2 = new System.Windows.Forms.TextBox();
            this.Consolebutton1 = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // Conbutton1
            // 
            this.Conbutton1.Enabled = false;
            this.Conbutton1.Location = new System.Drawing.Point(28, 124);
            this.Conbutton1.Name = "Conbutton1";
            this.Conbutton1.Size = new System.Drawing.Size(113, 47);
            this.Conbutton1.TabIndex = 0;
            this.Conbutton1.Text = "Connecton";
            this.Conbutton1.UseVisualStyleBackColor = true;
            this.Conbutton1.Click += new System.EventHandler(this.button1_Click);
            // 
            // loginlabel
            // 
            this.loginlabel.AutoSize = true;
            this.loginlabel.Location = new System.Drawing.Point(4, 68);
            this.loginlabel.Name = "loginlabel";
            this.loginlabel.Size = new System.Drawing.Size(29, 13);
            this.loginlabel.TabIndex = 2;
            this.loginlabel.Text = "login";
            // 
            // passlabel
            // 
            this.passlabel.AutoSize = true;
            this.passlabel.Location = new System.Drawing.Point(3, 96);
            this.passlabel.Name = "passlabel";
            this.passlabel.Size = new System.Drawing.Size(30, 13);
            this.passlabel.TabIndex = 3;
            this.passlabel.Text = "Pass";
            // 
            // LogintextBox
            // 
            this.LogintextBox.Location = new System.Drawing.Point(41, 61);
            this.LogintextBox.Name = "LogintextBox";
            this.LogintextBox.Size = new System.Drawing.Size(100, 20);
            this.LogintextBox.TabIndex = 4;
            // 
            // PasstextBox
            // 
            this.PasstextBox.Location = new System.Drawing.Point(41, 89);
            this.PasstextBox.Name = "PasstextBox";
            this.PasstextBox.Size = new System.Drawing.Size(100, 20);
            this.PasstextBox.TabIndex = 5;
            this.PasstextBox.TextChanged += new System.EventHandler(this.PasstextBox_TextChanged);
            // 
            // Quitbutton
            // 
            this.Quitbutton.Location = new System.Drawing.Point(182, 124);
            this.Quitbutton.Name = "Quitbutton";
            this.Quitbutton.Size = new System.Drawing.Size(93, 46);
            this.Quitbutton.TabIndex = 6;
            this.Quitbutton.Text = "Quit";
            this.Quitbutton.UseVisualStyleBackColor = true;
            this.Quitbutton.Click += new System.EventHandler(this.Quitbutton_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ControlDark;
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.textBox1);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.Quitbutton);
            this.panel1.Controls.Add(this.PasstextBox);
            this.panel1.Controls.Add(this.LogintextBox);
            this.panel1.Controls.Add(this.passlabel);
            this.panel1.Controls.Add(this.loginlabel);
            this.panel1.Controls.Add(this.Conbutton1);
            this.panel1.Location = new System.Drawing.Point(21, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(309, 187);
            this.panel1.TabIndex = 7;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(215, 66);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(37, 18);
            this.label2.TabIndex = 9;
            this.label2.Text = "You";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(182, 89);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(107, 20);
            this.textBox1.TabIndex = 8;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(36, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(151, 25);
            this.label1.TabIndex = 7;
            this.label1.Text = "Enter MySQL";
            // 
            // NameNewtextBox2
            // 
            this.NameNewtextBox2.Location = new System.Drawing.Point(86, 34);
            this.NameNewtextBox2.Name = "NameNewtextBox2";
            this.NameNewtextBox2.Size = new System.Drawing.Size(104, 20);
            this.NameNewtextBox2.TabIndex = 8;
            // 
            // Namelabel
            // 
            this.Namelabel.AutoSize = true;
            this.Namelabel.Location = new System.Drawing.Point(45, 37);
            this.Namelabel.Name = "Namelabel";
            this.Namelabel.Size = new System.Drawing.Size(35, 13);
            this.Namelabel.TabIndex = 9;
            this.Namelabel.Text = "Name";
            // 
            // Grantlabel
            // 
            this.Grantlabel.AutoSize = true;
            this.Grantlabel.Location = new System.Drawing.Point(45, 85);
            this.Grantlabel.Name = "Grantlabel";
            this.Grantlabel.Size = new System.Drawing.Size(38, 13);
            this.Grantlabel.TabIndex = 10;
            this.Grantlabel.Text = "Grants";
            // 
            // GrantNewtextBox3
            // 
            this.GrantNewtextBox3.Location = new System.Drawing.Point(86, 85);
            this.GrantNewtextBox3.Name = "GrantNewtextBox3";
            this.GrantNewtextBox3.Size = new System.Drawing.Size(104, 20);
            this.GrantNewtextBox3.TabIndex = 11;
            // 
            // Cratebutton
            // 
            this.Cratebutton.Location = new System.Drawing.Point(97, 120);
            this.Cratebutton.Name = "Cratebutton";
            this.Cratebutton.Size = new System.Drawing.Size(65, 39);
            this.Cratebutton.TabIndex = 12;
            this.Cratebutton.Text = "Creat User";
            this.Cratebutton.UseVisualStyleBackColor = true;
            this.Cratebutton.Click += new System.EventHandler(this.Cratebutton_Click);
            // 
            // CreatNewbutton1
            // 
            this.CreatNewbutton1.Enabled = false;
            this.CreatNewbutton1.Location = new System.Drawing.Point(33, 82);
            this.CreatNewbutton1.Name = "CreatNewbutton1";
            this.CreatNewbutton1.Size = new System.Drawing.Size(72, 49);
            this.CreatNewbutton1.TabIndex = 13;
            this.CreatNewbutton1.Text = "Creat new DB";
            this.CreatNewbutton1.UseVisualStyleBackColor = true;
            this.CreatNewbutton1.Click += new System.EventHandler(this.CreatNewbutton1_Click);
            // 
            // NewDbtextBox4
            // 
            this.NewDbtextBox4.Location = new System.Drawing.Point(111, 98);
            this.NewDbtextBox4.Name = "NewDbtextBox4";
            this.NewDbtextBox4.Size = new System.Drawing.Size(60, 20);
            this.NewDbtextBox4.TabIndex = 14;
            this.NewDbtextBox4.TextChanged += new System.EventHandler(this.NewDbtextBox4_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(111, 82);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 13);
            this.label3.TabIndex = 15;
            this.label3.Text = "Name DB";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(28, 26);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(159, 25);
            this.label4.TabIndex = 16;
            this.label4.Text = "Creat New DB";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ControlLight;
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.NewDbtextBox4);
            this.panel2.Controls.Add(this.CreatNewbutton1);
            this.panel2.Location = new System.Drawing.Point(21, 218);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(212, 163);
            this.panel2.TabIndex = 17;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // PassNewtextBox4
            // 
            this.PassNewtextBox4.Location = new System.Drawing.Point(86, 60);
            this.PassNewtextBox4.Name = "PassNewtextBox4";
            this.PassNewtextBox4.Size = new System.Drawing.Size(104, 20);
            this.PassNewtextBox4.TabIndex = 18;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(48, 63);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(30, 13);
            this.label5.TabIndex = 19;
            this.label5.Text = "Pass";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.Location = new System.Drawing.Point(30, 4);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(182, 25);
            this.label6.TabIndex = 20;
            this.label6.Text = " User with Grant";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.ControlLight;
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.label6);
            this.panel3.Controls.Add(this.label5);
            this.panel3.Controls.Add(this.PassNewtextBox4);
            this.panel3.Controls.Add(this.Cratebutton);
            this.panel3.Controls.Add(this.GrantNewtextBox3);
            this.panel3.Controls.Add(this.Grantlabel);
            this.panel3.Controls.Add(this.Namelabel);
            this.panel3.Controls.Add(this.NameNewtextBox2);
            this.panel3.Location = new System.Drawing.Point(363, 3);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(253, 186);
            this.panel3.TabIndex = 21;
            // 
            // ConsoletextBox2
            // 
            this.ConsoletextBox2.Location = new System.Drawing.Point(76, 398);
            this.ConsoletextBox2.Name = "ConsoletextBox2";
            this.ConsoletextBox2.Size = new System.Drawing.Size(450, 20);
            this.ConsoletextBox2.TabIndex = 22;
            this.ConsoletextBox2.TextChanged += new System.EventHandler(this.ConsoletextBox2_TextChanged);
            // 
            // Consolebutton1
            // 
            this.Consolebutton1.Enabled = false;
            this.Consolebutton1.Location = new System.Drawing.Point(541, 396);
            this.Consolebutton1.Name = "Consolebutton1";
            this.Consolebutton1.Size = new System.Drawing.Size(75, 23);
            this.Consolebutton1.TabIndex = 23;
            this.Consolebutton1.Text = "Enter";
            this.Consolebutton1.UseVisualStyleBackColor = true;
            this.Consolebutton1.Click += new System.EventHandler(this.Consolebutton1_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(676, 18);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(496, 523);
            this.dataGridView1.TabIndex = 24;
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(82, 453);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(444, 59);
            this.richTextBox1.TabIndex = 25;
            this.richTextBox1.Text = "";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1184, 567);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.Consolebutton1);
            this.Controls.Add(this.ConsoletextBox2);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Conbutton1;
        private System.Windows.Forms.Label loginlabel;
        private System.Windows.Forms.Label passlabel;
        private System.Windows.Forms.TextBox LogintextBox;
        private System.Windows.Forms.TextBox PasstextBox;
        private System.Windows.Forms.Button Quitbutton;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox NameNewtextBox2;
        private System.Windows.Forms.Label Namelabel;
        private System.Windows.Forms.Label Grantlabel;
        private System.Windows.Forms.TextBox GrantNewtextBox3;
        private System.Windows.Forms.Button Cratebutton;
        private System.Windows.Forms.Button CreatNewbutton1;
        private System.Windows.Forms.TextBox NewDbtextBox4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox PassNewtextBox4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox ConsoletextBox2;
        private System.Windows.Forms.Button Consolebutton1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.RichTextBox richTextBox1;
    }
}

