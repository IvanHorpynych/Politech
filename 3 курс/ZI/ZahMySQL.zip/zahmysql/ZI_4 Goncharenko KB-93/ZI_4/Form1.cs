﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
namespace ZI_4
{
    public partial class Form1 : Form
    {

      

        MySqlConnection conn = new MySqlConnection();
        string connString;
        MySqlCommand command;//= conn.CreateCommand();
        private BindingSource bindingSorce = new BindingSource();

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            connString = "Server=localhost;Uid="+LogintextBox.Text+";password="+PasstextBox.Text;
          
            conn.ConnectionString = connString;
          
             richTextBox1.Text += connString +"\n";
            try
            {
                conn.Open();
                MessageBox.Show("Entered to MySQL","Acepted");
                textBox1.Text = LogintextBox.Text;
              //  errorBox.Text = "Good conection";
            }
            catch (Exception ex)
            {
                //errorBox.Text = ex.Message;
                MessageBox.Show(ex.Message,"error!");
            }
            
            
            LogintextBox.Text = "";
            PasstextBox.Text = "";
           
        }

        private void PasstextBox_TextChanged(object sender, EventArgs e)
        {
            if ((PasstextBox.Text != "")&&(LogintextBox.Text!=""))
            {
                Conbutton1.Enabled = true;
            }
            else
                Conbutton1.Enabled = false;
        }

        private void Quitbutton_Click(object sender, EventArgs e)
        {
           conn.Close();
            textBox1.Text = "";
            ConsoletextBox2.Text = "";
            //richTextBox1.Text = "";
            
             NewDbtextBox4.Text = "";
            NameNewtextBox2.Text = "";
            GrantNewtextBox3.Text = "";
            PassNewtextBox4.Text = "";
            dataGridView1.Columns.Clear();
            

        }

        private void errorBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void NewDbtextBox4_TextChanged(object sender, EventArgs e)
        {
            if (NewDbtextBox4.Text != "")
            {
               CreatNewbutton1.Enabled = true;
            }
            else
                CreatNewbutton1.Enabled = false;
        }

        private void CreatNewbutton1_Click(object sender, EventArgs e)
        {
            command = conn.CreateCommand();
            command.CommandText = "create database "+NewDbtextBox4.Text +";";
            richTextBox1.Text += command.CommandText + "\n";
           // DataSet myDataSet = new DataSet();
            //MySqlDataAdapter  adapter = new MySqlDataAdapter();
            try
            {
               
                command.ExecuteNonQuery();
                MessageBox.Show("Creat New DB", "OK!");
               
            }
            catch (Exception ex)
            {
                //errorBox.Text = ex.Message;
                MessageBox.Show(ex.Message, "error!");
            }
           

        }

        private void Consolebutton1_Click(object sender, EventArgs e)
        {
       
       string CommandText =ConsoletextBox2.Text ;
       richTextBox1.Text += ConsoletextBox2.Text + "\n";
       MySqlCommand cmd = new MySqlCommand(); 
            // command = conn.CreateCommand();
       cmd.Connection = conn;
            cmd.CommandText = ConsoletextBox2.Text ;
           
            // myCommand = new MySqlCommand(Command.CommandText, myConnection);
            DataSet myDataSet = new DataSet();
            MySqlDataAdapter adapter= new MySqlDataAdapter (cmd);
            
            try
            {
               
               // command.ExecuteNonQuery();
               
                adapter.Fill(myDataSet);
                //if (myDataSet.Tables.Count > 0)
                   // dataGridView1.DataSource = myDataSet.Tables[0];
                    bindingSorce.DataSource = myDataSet.Tables[0];
                    dataGridView1.DataSource = bindingSorce;
                    MessageBox.Show("OK!", "OK!");
                //  errorBox.Text = "Good conection";
            }
            catch (Exception ex)
            {
                //errorBox.Text = ex.Message;
                MessageBox.Show(ex.Message, "error!");
            }
            //DataSource = DB.ResultData.DefaultView;
            
            /*
            MySqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                errorBox.Text = reader["text"].ToString();
            }*/
        }

        private void ConsoletextBox2_TextChanged(object sender, EventArgs e)
        {
            if (ConsoletextBox2.Text  != "")
            {
                Consolebutton1.Enabled = true;
            }
            else
                 Consolebutton1.Enabled = false;
        }

        private void Cratebutton_Click(object sender, EventArgs e)
        {
            command = conn.CreateCommand();
            command.CommandText = "grant " + GrantNewtextBox3.Text + "  to " + NameNewtextBox2.Text + "@" + "localhost identified by "+"'" + PassNewtextBox4.Text + "';";
            richTextBox1.Text +=  command.CommandText + "\n";
            try
            {

                command.ExecuteNonQuery();
                MessageBox.Show("Creat New User", "OK!");

            }
            catch (Exception ex)
            {
                //errorBox.Text = ex.Message;
                MessageBox.Show(ex.Message, "error!");
            }
           
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

     /*   private void Showbutton1_Click(object sender, EventArgs e)
        {

            command = conn.CreateCommand();
            command.CommandText = ShowtextBox2.Text;

            try
            {

                command.ExecuteNonQuery();
                MessageBox.Show("OK!", "OK!");
                //  errorBox.Text = "Good conection";
            }
            catch (Exception ex)
            {
                //errorBox.Text = ex.Message;
                MessageBox.Show(ex.Message, "error!");
            }
            
            MySqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                errorBox.Text = reader.;
            }
        }*/

    }
}
