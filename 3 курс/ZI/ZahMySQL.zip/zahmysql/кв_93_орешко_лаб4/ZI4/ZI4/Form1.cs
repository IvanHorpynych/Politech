﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace ZI4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //  Коннектор для работы с MySQL
        MySqlConnection Connector = new MySqlConnection();

        MySqlCommand Command;

        string ConnectionString;

        private BindingSource bindingSorce = new BindingSource();

        //  Подсоединение к MySQL
        private void button1_Click(object sender, EventArgs e)
        {
            ConnectionString = "Server = localhost; Uid = " + textBox1.Text+"; password = " + textBox2.Text;

            Connector.ConnectionString = ConnectionString;

            richTextBox1.Text += ConnectionString + "\n";

            try
            {
                Connector.Open();
                richTextBox2.Text = "Entered to MySQL\n";
                richTextBox2.AppendText("Current user: " + textBox1.Text);
            }
            catch (Exception ex)
            {
                richTextBox2.Text = "Error:  Can't connect to MySQL";
                richTextBox1.Text = "";
                textBox1.Text = "";
                textBox2.Text = "";
            }           

        }

        //  Отсоединение от MySQL
        private void button2_Click(object sender, EventArgs e)
        {
            Connector.Close();
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
            textBox6.Text = "";
            richTextBox1.Text = "";
            richTextBox2.Text = "Quit:   Bye!";
            richTextBox3.Text = "";
            dataGridView1.Columns.Clear();
        }

        //  Создание новой базы даных
        private void button3_Click(object sender, EventArgs e)
        {
            Command = Connector.CreateCommand();
            Command.CommandText = "create database " + textBox3.Text + ";";
            richTextBox1.AppendText(Command.CommandText + "\n");

            try
            {
                Command.ExecuteNonQuery();
                richTextBox2.Text = "New database created";
            }
            catch (Exception ex)
            {
                richTextBox2.Text = "Error, can't create database";
            }
        }

        //  Создание нового пользователя
        private void button4_Click(object sender, EventArgs e)
        {
            Command = Connector.CreateCommand();
            Command.CommandText = "grant " + textBox6.Text + "  to " + textBox4.Text + "@localhost identified by " + "'" + textBox5.Text + "';";
            richTextBox1.AppendText(Command.CommandText + "\n");

            try
            {
                Command.ExecuteNonQuery();
                richTextBox2.Text = "New user created";
            }
            catch (Exception ex)
            {
                richTextBox2.Text = "Error, can't create new user";
            }

        }

        //  Ввод комманды из коммандной строки
        private void button5_Click(object sender, EventArgs e)
        {
            Command = Connector.CreateCommand();
            Command.CommandText = richTextBox3.Text;
            richTextBox1.AppendText(Command.CommandText + "\n");

            try
            {
                Command.ExecuteNonQuery();
                richTextBox2.Text = "OK";
            }
            catch (Exception ex)
            {
                richTextBox2.Text = "Error";
            }
        }

        //  Удаление базы даных
        private void button6_Click(object sender, EventArgs e)
        {
            Command = Connector.CreateCommand();
            Command.CommandText = "drop database " + textBox7.Text + ";";
            richTextBox1.AppendText(Command.CommandText + "\n");

            try
            {
                Command.ExecuteNonQuery();
                richTextBox2.Text = "Database is deleted";
            }
            catch (Exception ex)
            {
                richTextBox2.Text = "Error, can't delete database";
            }

        }

        //  Создание новой таблицы
        private void button7_Click(object sender, EventArgs e)
        {
            Command = Connector.CreateCommand();
            Command.CommandText = "create table " + textBox8.Text + "." + textBox9.Text + " " + textBox10.Text + ";";
            richTextBox1.AppendText(Command.CommandText + "\n");

            try
            {
                Command.ExecuteNonQuery();
                richTextBox2.Text = "Table is createdted";
            }
            catch (Exception ex)
            {
                richTextBox2.Text = "Error, can't create table";
            }
        }

        //  Вставка даных в таблицу
        private void button8_Click(object sender, EventArgs e)
        {
            Command = Connector.CreateCommand();
            Command.CommandText = "insert into " + textBox11.Text + "." + textBox12.Text + " " + textBox13.Text + " values " + textBox14.Text + ";";
            richTextBox1.AppendText(Command.CommandText + "\n");

            try
            {
                Command.ExecuteNonQuery();
                richTextBox2.Text = "Data is inserted";
            }
            catch (Exception ex)
            {
                richTextBox2.Text = "Error, can't insert data";
            }

        }

        //  Просмотр таблицы
        private void button9_Click(object sender, EventArgs e)
        {
            string CommandText = "select * from " + textBox15.Text + "." + textBox16.Text + ";";
            richTextBox1.AppendText(CommandText + "\n");
            MySqlDataAdapter Adapter = new MySqlDataAdapter();
            Adapter.SelectCommand = new MySqlCommand(CommandText, Connector);
            DataTable table = new DataTable();
            
            BindingSource BSource = new BindingSource();
            try
            {
                Adapter.Fill(table);
                BSource.DataSource = table;
                dataGridView1.DataSource = BSource;
                richTextBox2.Text = "OK";
            }
            catch (Exception ex)
            {
                richTextBox2.Text = "Error, can't select table";
            }
        }

        //  Снятие привилегий Revoke
        private void button10_Click(object sender, EventArgs e)
        {
            Command = Connector.CreateCommand();
            Command.CommandText = "revoke " + textBox18.Text + " on " + textBox19.Text + "." + textBox20.Text + " from " + textBox17.Text + "@localhost;";
            richTextBox1.AppendText(Command.CommandText + "\n");

            try
            {
                Command.ExecuteNonQuery();
                richTextBox2.Text = "OK";
            }
            catch (Exception ex)
            {
                richTextBox2.Text = "Error";
            }
        }

        //  Удаление пользователя
        private void button11_Click(object sender, EventArgs e)
        {
            Command = Connector.CreateCommand();
            Command.CommandText = "delete from user where user = '" + textBox21.Text + "';";
            richTextBox1.AppendText(Command.CommandText + "\n");

            try
            {
                Command.ExecuteNonQuery();
                richTextBox2.Text = "User is deleted";
            }
            catch (Exception ex)
            {
                richTextBox2.Text = "Error, can't delete user";
            }
        }
    }
}
