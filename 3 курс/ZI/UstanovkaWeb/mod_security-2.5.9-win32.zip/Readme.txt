13 March 2009                              Apache Lounge Distribution

                           mod_security-2.5.9 with libxml2-2.7.2 and lua-5.1.4


# Original source by: Ivan Ristic <ivanr@webkreator.com>
# Original Home: http://www.modsecurity.org/
#
# Win32 binary by: Steffen
# Mail: info@apachelounge.com
# Home: http://www.apachelounge.com/
#
# Works only with Apache 2.2.x
#
# 

# Notes:

- Lua is build inline, no need to have lua5.1.dll

- The module is build with Visual Studio� 2008,
  be sure to install the new Visual C++ 2008 Redistributable Package,see below.


# Install:

- Create .../apache2/modules/mod_security2 and copy mod_security2.so and libxml2.dll to this folder

- Install the Visual C++ 2008 Redistributable Package 

  Download, if you not done it already, from:

  www.microsoft.com/downloads/details.aspx?FamilyID=9B2DA534-3E03-4391-8A4D-074B9F2BC1BF&displaylang=en


# Add to your httpd.conf:

- LoadModule security2_module modules/mod_security2/mod_security2.so

- Enable the module unique_id by uncommenting:

  LoadModule unique_id_module modules/mod_unique_id.so


# Configuration: see the included documentation

# A very quick start:

SecRuleEngine On
SecDefaultAction log,auditlog,deny,status:403,phase:2,t:lowercase,t:replaceNulls,t:compressWhitespace

SecAuditEngine RelevantOnly
SecAuditLogType Serial
SecAuditLog logs/mod_security2.log


## -- General rules --------------------

SecRule ARGS "c:/" t:normalisePathWin 
SecRule ARGS "\.\./" "t:normalisePathWin,id:99999,severity:4,msg:'Drive Access'" 
SecRule ARGS "d:/" t:normalisePathWin

## -- phpBB attack --------------------
SecRule ARGS:highlight "(\x27|%27|\x2527|%2527)"



To check your mod_security, add the rule: 

Call your site with: 

http://www.xxxxcom/?abc=../../ 

You should get a access denied,
this triggered by the above rule SecRule ARGS "\.\./" t:normalisePathWin


Enjoy,

Steffen