function dy = fun1_5_y(x, y, z)
dy = exp(-(pow(x, 2) + pow(z, 2))) + 2 * x;]
dz = 2 * pow(y, 2) + z;
end