function dy = fun1_4_y(x, y, z)
dz = 2 / (x + 2 * pow(y, 2)) + x + 1;
dy = cos(y + 2 * z) + 2;
end