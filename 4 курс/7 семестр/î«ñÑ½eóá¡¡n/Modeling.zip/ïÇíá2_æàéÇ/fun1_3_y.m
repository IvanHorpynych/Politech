function dz = fun1_3_y(x, y, z)
dy = (z - y) * x;
dz = (z + y) * x;
end