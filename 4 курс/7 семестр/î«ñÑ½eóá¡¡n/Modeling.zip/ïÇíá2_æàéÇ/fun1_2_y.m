function dy = fun1_2_y(x, y, z)
dz = (2 * pow(z, 2))/(x * (y - 1)) + z / x;
dy = z / x;
end
