function dx = fun1_1(t, x)
dx = sin(t) - 2 * x ;
end