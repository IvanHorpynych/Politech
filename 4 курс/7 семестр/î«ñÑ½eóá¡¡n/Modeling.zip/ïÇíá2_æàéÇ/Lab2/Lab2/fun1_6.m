function ddy = fun1_6(x, y, dy)
ddy = - dy/x + y/pow(x, 2) + 1;
end