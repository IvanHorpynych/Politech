function dy = fun1_3_z(x, y, z)
dz = (z + y) * x;
dy = (z - y) * x;
end