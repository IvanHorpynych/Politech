function sol=f(t);
    sol=(exp(-2*t)-cos(t)+2*sin(t))/5;
