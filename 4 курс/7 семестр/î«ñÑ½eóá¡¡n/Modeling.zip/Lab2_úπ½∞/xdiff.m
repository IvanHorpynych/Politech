function dx = xdiff(t, x)
    dx = sin(t) - 2 * x;
end
